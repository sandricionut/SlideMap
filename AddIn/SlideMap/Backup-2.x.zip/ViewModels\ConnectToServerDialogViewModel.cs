﻿using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Controls;
using System.Windows.Input;

namespace SlideMap.ViewModels
{
    public class ConnectToServerDialogViewModel : PropertyChangedBase
    {
        public string UserName { get; set; }
        public string UgCSServer { get; set; }
        public string Password { get; set; }

        public ICommand CmdOk => new RelayCommand((proWindow) =>
        {
            SlideMapModule.UgCSServer = UgCSServer;
            SlideMapModule.UserName = UserName;
            SlideMapModule.Password = Password;

            (proWindow as ProWindow).DialogResult = true;
            (proWindow as ProWindow).Close();
        }, () => true);

        public ICommand CmdCancel => new RelayCommand((proWindow) =>
        {
            SlideMapModule.UgCSServer = string.Empty;
            SlideMapModule.UserName = string.Empty;
            SlideMapModule.Password = string.Empty;
            // TODO: set dialog result and close the window
            (proWindow as ProWindow).DialogResult = false;
            (proWindow as ProWindow).Close();
        }, () => true);
    }
}