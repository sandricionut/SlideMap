﻿namespace SlideMap.Enum
{
    public enum TurnTypeEnum
    {
        StopAndTurn = 0,
        Spline = 1
    }
}