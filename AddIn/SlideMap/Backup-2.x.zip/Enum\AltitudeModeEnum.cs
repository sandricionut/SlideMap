﻿namespace SlideMap.Enum
{
    public enum AltitudeModeEnum
    {
        AGL = 0,
        AMSL = 1
    }
}