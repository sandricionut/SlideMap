﻿using ArcGIS.Desktop.Framework.Controls;
using SlideMap.ViewModels;

namespace SlideMap

{
    public partial class ConnectToServerDialog : ProWindow
    {
        private readonly ConnectToServerDialogViewModel _connectToServerDialogViewModel = new ConnectToServerDialogViewModel();

        public ConnectToServerDialog()
        {
            InitializeComponent();
            DataContext = _connectToServerDialogViewModel;
        }
    }
}
