﻿namespace SlideMap.Exceptions
{
    public class TheadExceptionModel
    {
        public string Message { get; set; }
        public int Status { get; set; }
    }
}
